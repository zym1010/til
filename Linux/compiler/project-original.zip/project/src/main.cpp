int foo();

#include <iostream>
int main()
	{
		std::cout << foo() << std::endl;
		return 0;
	}