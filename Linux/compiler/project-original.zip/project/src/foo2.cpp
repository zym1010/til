int foo()
	{ return 5; }