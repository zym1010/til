int bar()
	{ return 3; }